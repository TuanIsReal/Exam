/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tests.request;

import java.io.Serializable;

/**
 *
 * @author anhtu
 */
public class Response implements Serializable{
   public Object object ;

    public Response(Object object) {
        this.object = object;
    }
    
}

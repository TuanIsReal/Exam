/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tests.server;

import com.mycompany.tests.ConnectDB;
import com.mycompany.tests.deo.DepartmentDAO;
import com.mycompany.tests.deo.EmployeeDAO;
import com.mycompany.tests.model.Department;
import com.mycompany.tests.model.Employee;
import com.mycompany.tests.request.Method;
import com.mycompany.tests.request.Request;
import com.mycompany.tests.request.Response;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 *
 * @author anhtu
 */
public class Server {

    

        public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {
            ServerSocket serverTCP=new ServerSocket(8080);
            while (true) {                
                Socket socket =serverTCP.accept();
                try (ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream())) {
                    Request request=(Request)inputStream.readObject();
                    System.out.println(request);
                    if(request.getMethod()==Method.GET){
                        DepartmentDAO departmentDAO=new DepartmentDAO();
                        List<Department> list=departmentDAO.findAll();
                        for(Department d:list){
                            System.out.println(d);
                        }
                        Response response=new Response(list);
                        ObjectOutputStream objectOutputStream=new ObjectOutputStream(socket.getOutputStream());
                        objectOutputStream.writeObject(response);
                        objectOutputStream.flush();
                        objectOutputStream.close();
                    }
                    if(request.getMethod()==Method.DELETE){
                        ConnectDB cndb = new ConnectDB();
                        Statement st = cndb.con.createStatement();
                        int xoa = request.getDelete();
                        String sqlDelete = "DELETE FROM department Where DEPT_ID ="+xoa;
                        int num = st.executeUpdate(sqlDelete);
                    }
                    if(request.getMethod()==Method.GETE){
                        EmployeeDAO employeeDAO=new EmployeeDAO();
                        List<Employee> list=employeeDAO.findAll();
                        for(Employee d:list){
                            System.out.println(d);
                        }
                        Response response=new Response(list);
                        ObjectOutputStream objectOutputStream=new ObjectOutputStream(socket.getOutputStream());
                        objectOutputStream.writeObject(response);
                        objectOutputStream.flush();
                        objectOutputStream.close();
                    }
                    if(request.getMethod()==Method.DELETEE){
                        ConnectDB cndb = new ConnectDB();
                        Statement st = cndb.con.createStatement();
                        int xoa = request.getDelete();
                        String sqlDelete = "DELETE FROM employee Where EMP_ID ="+xoa;
                        int num = st.executeUpdate(sqlDelete);
                    }
                    if(request.getMethod()==Method.POST){
                        DepartmentDAO departmentDAO=new DepartmentDAO();
                        ConnectDB cndb = new ConnectDB();
                        Statement st = cndb.con.createStatement();
                        int check = request.getDp().getId();
                        String sqlCheck = "Select count('DEPT_ID') from department Where DEPT_ID = "+check;
                        ResultSet rs=st.executeQuery(sqlCheck);
                        rs.next();
                        int numcheck = rs.getInt("count('DEPT_ID')");
                        System.out.println(numcheck);
                        if (numcheck == 0){
                            String sqlInsert = "INSERT INTO `department` VALUES ("+request.getDp().getId()+",'"+request.getDp().getNameString()+"','"+request.getDp().getNoString()+"','"+request.getDp().getLocaltionString()+"');";
                            int num = st.executeUpdate(sqlInsert);
                        }
                    }
                    if(request.getMethod()==Method.POSTE){
                        EmployeeDAO employeeDAO=new EmployeeDAO();
                        ConnectDB cndb = new ConnectDB();
                        Statement st = cndb.con.createStatement();
                        int check = request.getEp().getId();
                        String sqlCheck = "Select count('EMP_ID') from employee Where EMP_ID = "+check;
                        ResultSet rs=st.executeQuery(sqlCheck);
                        rs.next();
                        int numcheck = rs.getInt("count('EMP_ID')");
                        System.out.println(numcheck);
                        if (numcheck == 0){
                            String sqlInsert = "INSERT INTO `EMPLOYEE` VALUES ("+request.getEp().getId()+",'"+request.getEp().getNameString()+"','"+request.getEp().getNoString()+"','"+request.getEp().getDateString()+"','"+request.getEp().getImageString()+"','"+request.getEp().getJobString()+"',"+request.getEp().getSalary()+","+request.getEp().getDeptId()+","+request.getEp().getMngId()+")";
                            int num = st.executeUpdate(sqlInsert);
                        }
                    }
                }
               
            }
    }
}

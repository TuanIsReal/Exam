/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tests.deo;

import com.mycompany.tests.ConnectDB;
import com.mycompany.tests.model.Department;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anhtu
 */
public class DepartmentDAO {
    
    public DepartmentDAO() {
    }
    public Connection getConnection(){
           return new ConnectDB().con;
    }
    public List<Department> findAll() throws SQLException{
        String sqlString="select * from department";
           List<Department> departments=new ArrayList<>();
          Statement st = this.getConnection().createStatement();
           ResultSet rs=st.executeQuery(sqlString);
           while (rs.next())
      {
        int id = rs.getInt("DEPT_ID");
        String name = rs.getString("DEPT_NAME");
        String no = rs.getString("DEPT_NO");
        String location = rs.getString("LOCATION");
        departments.add(new Department(id, name, no, location));
        
      }
            st.close();
           return departments;
     
    }
       
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tests.deo;

import com.mycompany.tests.ConnectDB;
import com.mycompany.tests.model.Employee;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anhtu
 */
public class EmployeeDAO {

    public EmployeeDAO() {
    }
    
    public Connection getConnection(){
           return new ConnectDB().con;
    }
    
    public List<Employee> findAll() throws SQLException{
        String sqlString="select * from employee";
           List<Employee> employee=new ArrayList<>();
          Statement st = this.getConnection().createStatement();
           ResultSet rs=st.executeQuery(sqlString);
           while (rs.next())
      {
        int id = rs.getInt("EMP_ID");
        String name = rs.getString("EMP_NAME");
        String no = rs.getString("EMP_NO");
        String date = rs.getString("HIRE_DATE");
        String image = rs.getString("IMAGE");
        String job = rs.getString("JOB");
        int salary = rs.getInt("SALARY");
        int deptid = rs.getInt("DEPT_ID");
        int mngid = rs.getInt("MNG_ID");
        employee.add(new Employee(id, name, no, date, image, job, salary, deptid, mngid));
        
      }
            st.close();
           return employee;
     
    }
}

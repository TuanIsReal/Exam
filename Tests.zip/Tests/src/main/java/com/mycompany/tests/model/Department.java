/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tests.model;

import java.io.Serializable;

/**
 *
 * @author anhtu
 */
public class Department implements Serializable{
    private int id;
    private String nameString;
    private String noString;
    private String localtionString;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameString() {
        return nameString;
    }

    public void setNameString(String nameString) {
        this.nameString = nameString;
    }

    public String getNoString() {
        return noString;
    }

    public void setNoString(String noString) {
        this.noString = noString;
    }

    public String getLocaltionString() {
        return localtionString;
    }

    public void setLocaltionString(String localtionString) {
        this.localtionString = localtionString;
    }

    public Department(int id, String nameString, String noString, String localtionString) {
        this.id = id;
        this.nameString = nameString;
        this.noString = noString;
        this.localtionString = localtionString;
    }

    public Department() {
    }

    @Override
    public String toString() {
        return "Department{" + "id=" + id + ", nameString=" + nameString + ", noString=" + noString + ", localtionString=" + localtionString + '}';
    }
    
    public Object[] toObjects(){
        return new Object[]{
          id, nameString, noString, localtionString
        };
    }
    
}

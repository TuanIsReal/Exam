/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tests.model;

import java.io.Serializable;

/**
 *
 * @author anhtu
 */
public class Employee extends Department implements Serializable{
    private int id;
    private String nameString;
    private String noString;
    private String dateString;
    private String imageString;
    private String jobString;
    private int salary;
    private int deptId;
    private int mngId;

    public Employee(int id, String nameString, String noString, String dateString, String imageString, String jobString, int salary, int deptId, int mngId) {
        this.id = id;
        this.nameString = nameString;
        this.noString = noString;
        this.dateString = dateString;
        this.imageString = imageString;
        this.jobString = jobString;
        this.salary = salary;
        this.deptId = deptId;
        this.mngId = mngId;
    }

    
    

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameString() {
        return nameString;
    }

    public void setNameString(String nameString) {
        this.nameString = nameString;
    }

    public String getNoString() {
        return noString;
    }

    public void setNoString(String noString) {
        this.noString = noString;
    }

    public String getDateString() {
        return dateString;
    }

    public void setDateString(String dateString) {
        this.dateString = dateString;
    }

    public String getImageString() {
        return imageString;
    }

    public void setImageString(String imageString) {
        this.imageString = imageString;
    }

    public String getJobString() {
        return jobString;
    }

    public void setJobString(String jobString) {
        this.jobString = jobString;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public int getMngId() {
        return mngId;
    }

    public void setMngId(int mngId) {
        this.mngId = mngId;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    
    
     public Employee() {
    }

    
    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", nameString=" + nameString + ", noString=" + noString + ", dateString=" + dateString + ", imageString=" + imageString + ", jobString=" + jobString + ", salryString=" + salary + ", deptId=" + deptId + ", mngId=" + mngId + '}';
    }
    
    public Object[] toObjects(){
        return new Object[]{
          id, nameString, noString, dateString, imageString, jobString, salary, deptId, mngId
        };
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tests.request;

/**
 *
 * @author anhtu
 */
public class Method {
    public  static  int GET=1;
    public static  int POST=2;
    public static  int PUT=3;
    public static  int DELETE=4;
    public  static  int GETE=5;
    public  static  int DELETEE=6;
    public static  int POSTE=7;
}

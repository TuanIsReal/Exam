/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tests.request;

import com.mycompany.tests.model.Department;
import com.mycompany.tests.model.Employee;
import java.io.Serializable;

/**
 *
 * @author anhtu
 */
public class Request  implements Serializable{
    private int method;
    Department dp;
    private int delete;
    Employee ep;

    public Request() {
    }

    public Request(int method, Department dp, int delete, Employee ep) {
        this.method = method;
        this.dp = dp;
        this.delete = delete;
        this.ep = ep;
    }

    public int getMethod() {
        return method;
    }

    public void setMethod(int method) {
        this.method = method;
    }

    public Department getDp() {
        return dp;
    }

    public void setDp(Department dp) {
        this.dp = dp;
    }

    public int getDelete() {
        return delete;
    }

    public void setDelete(int delete) {
        this.delete = delete;
    }

    public Employee getEp() {
        return ep;
    }

    public void setEp(Employee ep) {
        this.ep = ep;
    }

    @Override
    public String toString() {
        return "Request{" + "method=" + method + ", dp=" + dp + ", delete=" + delete + ", ep=" + ep + '}';
    }

    


    
    
}
